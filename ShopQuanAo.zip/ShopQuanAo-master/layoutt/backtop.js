﻿$("#back-to-top").click(function () { return $("body, html").animate({ scrollTop: 0 }, 400), !1 });
$(function () { $('[data-toggle="tooltip"]').tooltip() });